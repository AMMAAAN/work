$(document).ready(function() {
	$("#help_post_already_voted").hide();
	$("#help_post_already_voted").removeClass('d-none');

	//setup before functions
	var typingTimer; //timer identifier
	var doneTypingInterval = 500; //time in ms, 2 second for example

	// search events
	$(".search").on('focus', function () {
		$(".search-results").removeClass('d-none');
		$(".main-container").attr('data-overlay',5);
	});

	$(".search").on('input propertychange paste', function () {
		clearTimeout(typingTimer);

		typingTimer = setTimeout(doneTyping, doneTypingInterval);
	});

	$(document).on('click', '.dropdown-toggle', function(e) {
		$(this).siblings(".dropdown-menu").toggle();
	});

	$('.sort-menu').on('change', function() {
		if ('URLSearchParams' in window)
		{
		    var searchParams = new URLSearchParams(window.location.search);
		    	searchParams.set("sort", this.value);

		    window.location.search = searchParams.toString();
		}
	});

	$(".article__body img").wrap(function() {
		url = this.hasAttribute("data-src") ? this.dataset.src : this.src;

      	return "<a href=" + url + " data-fancybox='gallery' rel='gallery'></a>";
    });

	//user is "finished typing," do something
	function doneTyping ()
	{
		$(".fa-search").toggleClass("d-none");
		$(".fa-spinner").toggleClass("d-none");

		triggerSearch();

		setTimeout(function() {
			$(".fa-search").toggleClass("d-none");
			$(".fa-spinner").toggleClass("d-none");
		}, 500);
	}

	function triggerSearch()
	{
		var timeoutID = null;
		str = $(".search").val();

	    var search_results = $('.results-list');
        	search_results.empty();

        $(".fa-search").removeClass("search--loading");

        $.ajax({
            url: '/help/ajax_search',
            type: 'POST',
            dataType: 'JSON',
            data: {
                'csrf_test_name': $('meta[name="csrf_token"]').attr('content'),
                'search_term': str
            },
            success: function (retData) {
                if((retData))
                {
                	$(search_results).html(retData);

                    search_results.removeClass('d-none');

                    $(".no-result").addClass('d-none');

                    $(search_results).append('<a class="view-results" href="/help/search?q='+str+'">View all results for <b>' + str + '</b></a>');
                }
                else
                {
                    search_results.addClass('d-none');
                    $(".no-result").removeClass('d-none');
                }
            },
            error: function() {
                console.log('Unexpected error occurred.', false);
            }
        });   
	}

	$(document).on('click', 'body', function(e) {
		if ($(e.target).hasClass('search'))
		{
			return false;
		}

		$(".search-results").addClass('d-none');
		$(".main-container").attr('data-overlay',0);
	});

	// show/hide sidebar menu dropdowns (for help section)
	$('.sidebar_dropdown  .dropdown__trigger').on('click', function(e){
		$(this).closest(".sidebar_dropdown").toggleClass('dropdown--active');

		return false;
	});

	$(document).on('click', '.dropdown__content', function (e) {
		e.stopPropagation();
	});

	// feedback votes
	$('.vote-help-post').on('click', function(e) {
		$(this).toggleClass("btn--loading");

		$.ajax({
			data: {
				'csrf_test_name': $('meta[name="csrf_token"]').attr('content'),
				'uid': $(this).attr("data-uid"),
				'vote': $(this).attr("data-value")
			},
			type: "POST",
			url: "/help/post/feedback",
			dataType: "JSON",
			success: function(retData) {
				if (retData?.error && !retData?.already_voted)
				{
					alert('Something went wrong while submitting your feedback.');

					return false;
				}

				$(".feedback-actions").fadeOut("slow");

				window.setTimeout(function() {
					$(".feedback-voted").fadeIn("slow");
				}, 500);
			},
			error: function() {
				alert('Unexpected error occurred.');
			}
		});
	});
});